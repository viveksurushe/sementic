import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UiComponent } from './ui/ui.component';
import { FormComponent } from './form/form.component';


const routes: Routes = [
  { path: '', component: UiComponent},
  { path: 'form', component: FormComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
